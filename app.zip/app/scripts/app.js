(function () {
    'use strict';

    var _templateBase = '../app/views/pages';

    angular.module('app', [
        'ngRoute',
        'ngMaterial',
        'ngAnimate'
    ])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/', {
            templateUrl: _templateBase + '/dashboard.html',
            controller: 'dashboardCtrl'
        });
        $routeProvider.otherwise({ redirectTo: '/' });
    }]);
})();