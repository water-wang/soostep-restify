(function () {
    'use strict';

    angular.module('app')
        .service('dashboardSvc', function () {

        });
})();