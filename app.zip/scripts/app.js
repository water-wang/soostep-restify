(function () {
    'use strict';

    var _templateBase = './views';

    angular.module('app', [
        'ngRoute',
        'ngMaterial',
        'ngAnimate'
    ])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/', {
            templateUrl: _templateBase+'/dashboard.html',
            controller: 'dashboardController'
        });
        $routeProvider.otherwise({redirectTo: '/'});
    }]);
})();