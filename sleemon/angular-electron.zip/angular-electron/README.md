https://scotch.io/tutorials/creating-desktop-applications-with-angularjs-and-github-electron

https://startbootstrap.com/template-overviews/sb-admin-2/