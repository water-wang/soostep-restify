(function () {
    'use strict';
    
    angular.module('app')
        .controller('customerController', ['customerService', '$scope', function (customerService, $scope) {
            $scope.Title = 'Angular Customer';
        }]);
})();


